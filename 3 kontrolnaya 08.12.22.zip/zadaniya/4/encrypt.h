#ifndef __ENCRYPT_H
#define __ENCRYPT_H

void encrypt(char*);

#endif