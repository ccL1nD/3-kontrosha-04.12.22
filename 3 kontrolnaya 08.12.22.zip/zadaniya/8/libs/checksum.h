#ifndef __CHECKSUM_H
#define __CHECKSUM_H

int checksum(char*);

#endif